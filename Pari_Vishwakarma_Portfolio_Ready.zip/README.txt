# Pari Vishwakarma — Portfolio

## Files
- `index.html` — complete portfolio
- `assets/profile.png` — profile photo

## GitHub Pages
Upload both `index.html` and the `assets` folder to the root of your repository.
Then open:
`https://pari9026861552-debug.github.io/my--portfolio/`

## Before publishing
1. Replace `YOUR_EMAIL@example.com` with your real email.
2. Replace the LinkedIn placeholder with your LinkedIn profile URL.
3. If you have a resume PDF, add it as `assets/resume.pdf` and change the Resume button/link as needed.
